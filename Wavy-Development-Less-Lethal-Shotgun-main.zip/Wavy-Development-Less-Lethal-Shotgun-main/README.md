Features:
+ User takes 0 damage 
+ Easy to setup
+ Custom Shot Gun
+ 8 Sec Rag Doll
+ Full Support

Looking for dev work? Or server files?

Join our discord : https://discord.gg/wySkZ7nNeC


HOW TO USE
Drag both folders into your server files and start them 

ensure wavydmg
ensure wavywpn

The shotgun it uses is the sawoff so it just replaces the old one mkae sure to use that one.

Made By Musty
