fx_version 'sleezy'
games { 'gta5' }

client_scripts {
    'weapon-dmg.lua'
}
