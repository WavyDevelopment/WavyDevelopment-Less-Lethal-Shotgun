resource_manifest_version '679-996150c95a1d251a5c0c7841ab2f0276878334f7'
description 'SPR Development wepons file'
files {
  'weapons.meta'
}

data_file 'WEAPONINFO_FILE_PATCH' 'weapons.meta'
